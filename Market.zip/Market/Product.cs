﻿public class Product
{
	public string ProductName, ProductType;
	public int StartHour, EndHour;
}
