﻿using System;
using System.Collections.Generic;

public static class ProductUtils
{
	public static IEnumerable<Product> ProductsAvailableNow;

	static ProductUtils()
	{
		ProductsAvailableNow = new List<Product>();
	}

	// Creating products and assigning into a list of type Products..
    public static List<Product> ListAllProducts
    {
        get
        {
            List<Product> allProducts = new List<Product>
        {
            new Product { ProductName = "Orange Juice", ProductType = "AllDay" },
            new Product { ProductName = "Breakfast Burrito", ProductType = "Limited", StartHour = 8, EndHour = 12 },
            new Product { ProductName = "Steak & Chips", ProductType = "Limited", StartHour = 12, EndHour = 21 },
            new Product { ProductName = "Chicken Sandwich", ProductType = "Limited", StartHour = 11, EndHour = 19 },
            new Product { ProductName = "Sam Adams Seasonal", ProductType = "Limited", StartHour = 17, EndHour = 23 }
        };

            return allProducts;
        }
    }

	//Updating the list of product type with available products as per current time.
    public static void UpdateListOfAvailableProducts()
	{
		var productList = (List<Product>)ProductsAvailableNow;

		productList.Clear();

		foreach (var product in ListAllProducts)
		{
			if (product.ProductType == "AllDay" || (product.StartHour <= DateTime.Now.Hour && product.EndHour > DateTime.Now.Hour))
			{
				productList.Add(new Product
				{
					ProductName = product.ProductName,
					ProductType = product.ProductType,
					StartHour = product.StartHour,
					EndHour = product.EndHour
				});
			}
		}
	}

	//Displaying all the products available as per the current time.
	public static void DisplayAvailableProducts()
	{
		Console.WriteLine("Products available current time of day:");

		foreach (var pan in ProductsAvailableNow)
		{
			if (pan.ProductType == "AllDay")
				Console.WriteLine(pan.ProductName);
			else
			{
				pan.ProductName += " (" + pan.StartHour + ":00" + "-" + pan.EndHour + ":00" + ")";
				Console.WriteLine(pan.ProductName);
			}
		}
	}
}
