﻿using System;
using System.Linq;

internal class Program
{
	static void Main()
	{
		//Calling function of ProductUtil class which updates the list with available products into the list..
		ProductUtils.UpdateListOfAvailableProducts();
		if (ProductUtils.ProductsAvailableNow.Count() == 0)
			Console.WriteLine("There are no products available at this time of day");
		//Displaying the list of available list of products..
		else
			ProductUtils.DisplayAvailableProducts();

		Console.ReadKey();
	}
}